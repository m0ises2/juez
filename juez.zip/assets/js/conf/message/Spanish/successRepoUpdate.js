$(document).ready(function()
{
    toastr.success('Exitosamente','Repositorio Actualizado');
});