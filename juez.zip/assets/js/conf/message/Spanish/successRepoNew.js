 $(document).ready(function()
{
    toastr.success('Exitosamente','Repositorio Creado');
});