 $(document).ready(function()
{
    toastr.success('Exitosamente','Maraton Rejuzgado');
});