$(document).ready(function()
{
    toastr.success('Exitosamente','Repositorio Eliminado');
});