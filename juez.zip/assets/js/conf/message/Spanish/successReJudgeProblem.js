 $(document).ready(function()
{
    toastr.success('Exitosamente','Problema Rejuzgado');
});