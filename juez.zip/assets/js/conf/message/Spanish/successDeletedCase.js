$(document).ready(function()
{
    toastr.success('Exitosamente','Caso Eliminado');
});