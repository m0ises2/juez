$(document).ready(function()
{
    toastr.warning('Intente luego','No hay casos disponibles');
})