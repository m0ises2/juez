 $(document).ready(function()
{
    toastr.success('Exitosamente','Equipo Rechazado');
});