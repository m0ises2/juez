 $(document).ready(function()
{
    toastr.success('Exitosamente','Haz dejado al Equipo');
});