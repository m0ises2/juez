$(document).ready(function()
{
    toastr.success('Exitosamente','Lenguaje Añadido');

});
            
            
            
