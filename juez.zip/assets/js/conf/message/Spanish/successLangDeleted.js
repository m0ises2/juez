$(document).ready(function()
{
    toastr.success('Exitosamente','Lenguaje Eliminado');
});