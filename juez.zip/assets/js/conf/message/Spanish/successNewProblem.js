$(document).ready(function()
{
    toastr.success('Felicidades','Problema creado exitosamente');
});