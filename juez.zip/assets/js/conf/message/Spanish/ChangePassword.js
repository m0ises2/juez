$(document).ready(function()
{
    toastr.success('Exitosamente','Contraseña Actualizada');
});