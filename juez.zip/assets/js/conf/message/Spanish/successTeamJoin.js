 $(document).ready(function()
{
    toastr.success('Exitosamente','Unido al Equipo');
});