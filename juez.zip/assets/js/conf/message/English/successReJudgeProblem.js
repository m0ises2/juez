 $(document).ready(function()
{
    toastr.success('Congratulations','Problem Has Been ReJudge');
});