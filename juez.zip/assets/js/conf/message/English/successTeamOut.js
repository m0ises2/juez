 $(document).ready(function()
{
    toastr.success('Congratulations','You left the team');
});