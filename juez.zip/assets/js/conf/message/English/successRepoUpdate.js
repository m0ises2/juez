$(document).ready(function()
{
    toastr.success('Congratulations','Repository Has Been Update');
});