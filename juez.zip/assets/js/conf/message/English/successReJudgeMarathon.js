 $(document).ready(function()
{
    toastr.success('Congratulations','Marathon Has Been ReJudge');
});