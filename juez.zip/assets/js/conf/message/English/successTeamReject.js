 $(document).ready(function()
{
    toastr.success('Congratulations','Team Rejected');
});