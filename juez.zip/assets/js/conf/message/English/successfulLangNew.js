$(document).ready(function()
{
    toastr.success('Congratulations','Language Added');

});
            
            
            
