$(document).ready(function()
{
    toastr.warning('Sorry','No test cases available');
})