 $(document).ready(function()
{
    toastr.success('Congratulations','Joined the Team');
});