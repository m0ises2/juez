$(document).ready(function()
{
    toastr.success('Congratulations','Language Has Been Deleted');
});