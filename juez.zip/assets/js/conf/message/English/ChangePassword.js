$(document).ready(function()
{
    toastr.success('Congratulations','Password has been Changed');
});