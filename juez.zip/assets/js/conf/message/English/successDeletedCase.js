$(document).ready(function()
{
    toastr.success('Congratulations','Case Has Been Deleted');
});