<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol'] = 'sendmail';
$config['mailpath'] = '/usr/sbin/sendmail';
$config['charset']  = 'UTF-8';
$config['wordwrap'] = TRUE;
$config['mailtype'] = 'html';
